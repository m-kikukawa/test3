//>>built
define("dijit/ConfirmTooltipDialog",["dojo/_base/declare","./TooltipDialog","./_ConfirmDialogMixin"],function(a,b,c){return a("dijit.ConfirmTooltipDialog",[b,c],{})});
//# sourceMappingURL=ConfirmTooltipDialog.js.map